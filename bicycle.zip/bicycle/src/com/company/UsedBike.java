package com.company;

public class UsedBike extends Vehicle {


    // additional  atributes used bikes has
    private double KilometerTravel ;
    private boolean repair ;
    private  int NoOfOwners ;


    //constructor
    public UsedBike(String model, String make, String madeIn, String colour, String
            FuelType, String T, int ID, double speed, double power , double price, int
                            YearIntroduced, boolean Airbags , boolean Heater ,
                    boolean  Speakers, boolean FogLamps , double
                            KilometerTravel, int NoOfOwners, boolean repair)
    {
        super(model, make, madeIn, colour, FuelType,T, ID, speed,  power,price, YearIntroduced ,Airbags, Heater ,Speakers ,FogLamps) ;
        this.KilometerTravel=KilometerTravel;

        this.repair=repair;
        this.NoOfOwners=NoOfOwners ;
    }



    /*
    Seter and getter
    Description: the purpose of this fuctions :- Set and get the value of the instance variable
    */
    public void setPeriodOfUse(double KilometerTravel){
        this.KilometerTravel=KilometerTravel ;}


    public double getKilometerTravel(){
        return KilometerTravel ; }


    public void setRepair(boolean repair ){
        this.repair=repair;
    }


    public boolean getRepair(){
        return repair ;
    }




//Description: this function is type of override which used to show details of class

    @Override
    public String toString(){
        return super.toString()+ "\t"+getKilometerTravel()+"\t "+NoOfOwners+getRepair()+"\n";}


// Description:the purpose of this fuction :-  copy of the object on which it is called

    @Override
    public UsedBike clone (){
        UsedBike bike1=new UsedBike(model,make,madeIn,colour, FuelType,T,ID,speed,power,
                price,YearIntroduced, Airbags ,Heater,Speakers, FogLamps
                ,KilometerTravel,NoOfOwners,repair);
        return bike1;}


// Description:the purpose of this fuction :-  compare the object on which it is called with its parmeters

    @Override
    public boolean equals(Object m){
        UsedBike bike =(UsedBike)m;
        return super.equals(m)&&bike.KilometerTravel==KilometerTravel&&bike.repair==repair;
    }

}