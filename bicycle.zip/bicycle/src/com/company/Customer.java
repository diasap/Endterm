package com.company;

public class Customer extends Profile{
    //constructor
    public Customer(String name, String address, String contactNumber, String email, int ID) {
        super(name, address, contactNumber, email, ID);
    }
}
