package com.company;

public class NewBike extends Vehicle{


//constructor

    public NewBike(String model, String make, String madeIn,
                   String colour, String FuelType , String T, int ID , double speed, double power , double price, int YearIntroduced
            , boolean Airbags, boolean Heater  , boolean Speakers , boolean FogLamps  )
    {
        super(model, make, madeIn, colour,FuelType,T, ID, speed,  power,price,YearIntroduced,
                Airbags,Heater ,Speakers, FogLamps) ;

    }


    //Description: this function is type of override which used to show details ofatributes of class .

    @Override
    public String toString(){
        return
                super.toString();}


// Description:the purpose of this fuction :-  copy of the object on which it is called

    @Override
    public NewBike clone(){
        NewBike bike = new NewBike( model, make, madeIn, colour, FuelType ,T, ID, speed, power ,
                price,YearIntroduced, Airbags, Heater ,Speakers,
                FogLamps) ;
        return bike ;
    }


// Description:the purpose of this fuction :-  compare the object on which it is called with its parmeters

    @Override
    public boolean equals(Object o){
        return super.equals(o);
    }



}

